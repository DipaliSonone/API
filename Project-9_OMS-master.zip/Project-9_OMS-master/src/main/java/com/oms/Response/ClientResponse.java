package com.oms.Response;

import com.oms.dto.ClientDTO;

public class ClientResponse {

    private String status;
    private ClientDTO response;
    private String exception;

    public void ClientDTO(String status) {
        this.status = status;
    }


    public void setResponse(String s) {
    }
}
