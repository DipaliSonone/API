//package com.oms.controllers;
//
//import com.oms.dto.ClientDTO;
//import com.oms.exceptions.ClientAlreadyExistException;
//import com.oms.services.ClientService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.Optional;
//
//@RestController
//@RequestMapping("/client")
//public class ClientController1 {
//    @Autowired
//    ClientService clientService;
//
//    @PostMapping("/addClient")
//    public ResponseEntity<String>addClient(@RequestBody ClientDTO clientDTO){
//
//         try {
//             String s = clientService.addClient(clientDTO);
//             return ResponseEntity.status(HttpStatus.OK).body(s);
//         }catch (ClientAlreadyExistException clientAlreadyExistException){
//             return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Client Already Exist");
//         }
//    }
//
//    @GetMapping("/get/{clientId}")
//    public ResponseEntity<Optional<Object>> showClient(@PathVariable("clientId") Integer clientId) {
//        try {
//            Optional<Object> clientById = Optional.ofNullable(this.clientService.getClientById(clientId));
//            if (clientById.isPresent()) {
//                return ResponseEntity.ok(clientById);
//            } else {
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Optional.empty());
//            }
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Optional.empty());
//        }
//    }
//
//}
