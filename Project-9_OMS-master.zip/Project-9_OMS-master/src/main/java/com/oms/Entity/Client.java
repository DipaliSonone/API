package com.oms.Entity;

import com.oms.dto.ClientDTO;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
public class Client {
    @Id
    @Column(name= "client_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer clientId;
    @Column
    private String companyAddress;
    @Column
    private String companyRegNumber;
    @Column
    private OffsetDateTime dateOfBirth;

    @Column
    private OffsetDateTime dateOfJoining;

    @Column
    private String email;

    @Column
    private String firstName;

    @Column
    private String lastName;

    @Column
    private String gender;

    @Column
    private String gstNumber;

    @Column
    private String mobileNumber;

    @Column
    private String panNumber;

    @Column
    private String serviceOrProduct;

    @Column
    private String status;

    @Column(length = 45)
    private String userId;

    public Client() {
    }

    public Client(ClientDTO clientDTO) {
        this.companyAddress=clientDTO.getCompanyAddress();
        this.companyRegNumber=clientDTO.getCompanyRegNumber();
        this.firstName=clientDTO.getFirstName();
        this.dateOfBirth=clientDTO.getDateOfBirth();
        this.email=clientDTO.getEmail();
        this.mobileNumber=clientDTO.getMobileNumber();
        this.gender=clientDTO.getGender();
        this.panNumber=clientDTO.getPanNumber();
        this.gstNumber=clientDTO.getGstNumber();
        this.status=clientDTO.getStatus();
        this.serviceOrProduct=clientDTO.getServiceOrProduct();
        this.dateOfJoining=clientDTO.getDateOfJoining();
        this.lastName=clientDTO.getLastName();
        this.clientId=clientDTO.getClientId();
        this.userId=clientDTO.getUserId();


    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getCompanyRegNumber() {
        return companyRegNumber;
    }

    public void setCompanyRegNumber(String companyRegNumber) {
        this.companyRegNumber = companyRegNumber;
    }

    public OffsetDateTime getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(OffsetDateTime dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public OffsetDateTime getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(OffsetDateTime dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGstNumber() {
        return gstNumber;
    }

    public void setGstNumber(String gstNumber) {
        this.gstNumber = gstNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPanNumber() {
        return panNumber;
    }

    public void setPanNumber(String panNumber) {
        this.panNumber = panNumber;
    }

    public String getServiceOrProduct() {
        return serviceOrProduct;
    }

    public void setServiceOrProduct(String serviceOrProduct) {
        this.serviceOrProduct = serviceOrProduct;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }




}
