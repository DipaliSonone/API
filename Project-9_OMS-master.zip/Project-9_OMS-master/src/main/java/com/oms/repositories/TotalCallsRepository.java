package com.oms.repositories;

import com.oms.Entity.TotalCalls;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TotalCallsRepository extends JpaRepository<TotalCalls, Integer> {
}
