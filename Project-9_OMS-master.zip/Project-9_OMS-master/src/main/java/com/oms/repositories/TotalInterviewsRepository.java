package com.oms.repositories;

import com.oms.Entity.TotalInterviews;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TotalInterviewsRepository extends JpaRepository<TotalInterviews, Integer> {
}
