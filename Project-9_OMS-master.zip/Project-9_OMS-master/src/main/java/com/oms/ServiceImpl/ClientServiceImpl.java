package com.oms.ServiceImpl;

import com.oms.Entity.Client;
import com.oms.dto.ClientDTO;
import com.oms.exceptions.ClientAlreadyExistException;
import com.oms.exceptions.ClientNotFoundException;
import com.oms.exceptions.clientNotFoundByIdException;
import com.oms.repositories.ClientRepository;
import com.oms.services.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClientServiceImpl implements ClientService {
    @Autowired
    private ClientRepository clientRepository;
    @Override
    public String addClient(ClientDTO clientDTO) {
        Client email = clientRepository.findByEmail(clientDTO.getEmail());
        if (email==null){
            {
                Client client = new Client(clientDTO);
                clientRepository.save(client);
                return "Client Added Successfuly";

            }

        }
        else{
            throw new ClientAlreadyExistException("Client Already Exist");
        }
    }


    @Override
    public ClientDTO getClientById(Integer clientId) {
        Optional<Client> byId = this.clientRepository.findById(clientId);
        if (byId.isPresent()){

            Client client =byId.get();
            ClientDTO clientDTO =new ClientDTO();
            return this.toClientDTO(client);
        }else {
            throw new clientNotFoundByIdException("Client Not found");
        }
    }

    @Override
    public String deleteClientById(Integer clientId) throws ClientNotFoundException {

            Optional<Client> byId = this.clientRepository.findById(clientId);
            if (byId.isPresent()) {
                clientRepository.deleteById(clientId);
                return "Client deleted successfully";
            } else {
                throw new ClientNotFoundException("Client Not Found ");
            }

    }

    @Override
    public List<ClientDTO> getAllClients() {
        try {
            List<Client> clients = this.clientRepository.findAll();
            List<ClientDTO> clientDTOS = clients.stream().map(this::toClientDTO).collect(Collectors.toList());

            return clientDTOS;
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    @Override
    public Client updateClient(ClientDTO clientDTO, Integer clientId) {
        try {
            Client client = clientRepository.findById(clientId).orElse(null);

            if (client != null) {

                client.setCompanyAddress(clientDTO.getCompanyAddress());
                client.setCompanyRegNumber(clientDTO.getCompanyRegNumber());
                client.setDateOfBirth(clientDTO.getDateOfBirth());
                client.setDateOfJoining(clientDTO.getDateOfJoining());
                client.setEmail(clientDTO.getEmail());
                client.setFirstName(clientDTO.getFirstName());
                client.setLastName(clientDTO.getLastName());
                client.setGender(clientDTO.getGender());
                client.setGstNumber(clientDTO.getGstNumber());
                client.setMobileNumber(clientDTO.getMobileNumber());
                client.setPanNumber(clientDTO.getPanNumber());
                client.setServiceOrProduct(clientDTO.getServiceOrProduct());
                client.setStatus(clientDTO.getStatus());
                client.setUserId(clientDTO.getUserId());

                clientRepository.save(client);
            }
        } catch (Exception e) {

        }
        return null;
    }

    @Override
    public List<ClientDTO> getAllClient() {
        try {
            List<Client> clients = this.clientRepository.findAll();
            List<ClientDTO> clientDTOS = clients.stream().map(this::toClientDTO).collect(Collectors.toList());

            return clientDTOS;
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    private ClientDTO toClientDTO(Client client) {
        ClientDTO clientDTO = new ClientDTO();

        clientDTO.setClientId(client.getClientId());
        clientDTO.setCompanyAddress(client.getCompanyAddress());
        clientDTO.setCompanyRegNumber(client.getCompanyRegNumber());
        clientDTO.setDateOfBirth(client.getDateOfBirth());
        clientDTO.setDateOfJoining(client.getDateOfJoining());
        clientDTO.setEmail(client.getEmail());
        clientDTO.setFirstName(client.getFirstName());
        clientDTO.setLastName(client.getLastName());
        clientDTO.setGender(client.getGender());
        clientDTO.setGstNumber(client.getGstNumber());
        clientDTO.setMobileNumber(client.getMobileNumber());
        clientDTO.setPanNumber(client.getPanNumber());
        clientDTO.setServiceOrProduct(client.getServiceOrProduct());
        clientDTO.setStatus(client.getStatus());
        clientDTO.setUserId(client.getUserId());

        return clientDTO;
    }

//    private Client dtoToEntity(ClientDTO clientDTO) {
//        Client client = new Client();
//
//        client.setCompanyAddress(clientDTO.getCompanyAddress());
//        client.setCompanyRegNumber(clientDTO.getCompanyRegNumber());
//        client.setDateOfBirth(clientDTO.getDateOfBirth());
//        client.setDateOfJoining(clientDTO.getDateOfJoining());
//        client.setEmail(clientDTO.getEmail());
//        client.setFirstName(clientDTO.getFirstName());
//        client.setLastName(clientDTO.getLastName());
//        client.setGender(clientDTO.getGender());
//        client.setGstNumber(clientDTO.getGstNumber());
//        client.setMobileNumber(clientDTO.getMobileNumber());
//        client.setPanNumber(clientDTO.getPanNumber());
//        client.setServiceOrProduct(clientDTO.getServiceOrProduct());
//        client.setStatus(clientDTO.getStatus());
//        client.setUserId(clientDTO.getUserId());
//
//        return client;
//
//    }
}
