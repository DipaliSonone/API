package com.oms.exceptions;

public class ClientAlreadyExistException extends RuntimeException{
    public ClientAlreadyExistException(String message) {
        super(message);
    }
    public ClientAlreadyExistException(String s, String message){

    }

}
