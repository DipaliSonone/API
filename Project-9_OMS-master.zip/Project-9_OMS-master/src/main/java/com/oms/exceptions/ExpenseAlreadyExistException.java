package com.oms.exceptions;

public class ExpenseAlreadyExistException extends Throwable {
    public ExpenseAlreadyExistException(String message){
        super();
    }
}
