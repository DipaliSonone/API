package com.oms.exceptions;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class ExpenseNotFoundException extends RuntimeException {
    public ExpenseNotFoundException(String message){
        super();

    }


}
