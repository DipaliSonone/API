package com.oms.exceptions;

public class clientNotFoundByIdException extends RuntimeException {
    public clientNotFoundByIdException(String message){
        super();
    }
}
